# Scope 与 Memory

## 查找与盘点

- 在首次数据操作前调用 `resolve_scope_binding`，使用返回的 `scope_id`。不要自行创建或切换 Scope 来寻找缺失的结果。
- 用聚焦的查询调用 `search_memory`；先检查返回的状态和引用。空结果是正常结果，不应自动扩大为全量盘点。
- 用户要求盘点时，使用 `list_atomic_memories`，按返回的 `next_cursor` 翻页。默认只列活跃条目；只有明确审计时才包含 `forgotten`、`merged`、`retired`。
- 需要核对历史时，用精确的 ArtifactRef 调用 `get_artifact_revision`；当前内容和生命周期状态分别使用 `get_artifact`、`get_atomic_memory_state`。不要把旧版本当成当前状态。

## 保存与修改

仅在用户明确要求持久保存时调用 `remember_memory`。保存简洁且能独立理解的决定、约束、当前状态、任务结果或下一步；不要写入凭据、私密令牌或临时日志。检查返回的每个 ArtifactRef 后再报告结果。

纠正现有记忆时，先读取当前 Artifact 及 ETag，再用该 ETag 作为 `replace_artifact` 的 `If-Match` 前提。发生版本冲突后重新读取，不要以创建重复条目绕过冲突。请求让记忆退出通常搜索时，读取当前生命周期状态与 `state_version`，再调用相应的生命周期工具；这会保留可恢复的历史。

超时写入的结果未知，应先查询状态再决定是否重试。Source 采集只代表证据已接收，不能替代显式 Memory 保存。语义召回可能调用配置的 Embedding 服务并产生费用；遵守已有预算和授权。
