# 接入 PowerContext

本 Skill 是工作流指引，不自带 PowerContext Server 或 MCP 连接。先按[官方快速开始](https://powercontext.oceanbase.io/zh/docs/get-started/quickstart/)安装、配置 Server，并为所用 Agent 安装对应集成；支持范围以[集成能力矩阵](https://powercontext.oceanbase.io/zh/docs/integrations/capabilities/)为准。

PowerContext 的基础记忆模式支持显式保存与召回，无需独立模型 API。自动处理 Source、Topic Memory 和语义检索需要完整记忆能力及独立的 Generation、Embedding API 凭据。Agent 自身的模型订阅不自动提供 Server 凭据。

在执行数据操作前，确认 Agent 连接到预期 Server，并通过 `resolve_scope_binding` 获取真实的 `scope_id`。Scope ID 只选择数据，不授予身份或操作权限。若没有 PowerContext 工具，先完成宿主集成配置，再重试用户请求；不要用本地文件假冒服务端写入。

对外部发布、候选批准或更改连接配置，遵循当前宿主的权限控制与用户授权。Skill 文件本身不授予这些权限。
