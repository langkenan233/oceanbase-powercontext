---
name: powercontext-project-context
version: 1.0.0
description: 使用 PowerContext 查找或保存项目记忆、交接工作、审查 Experience 与 Skill 候选。适用于用户明确要求跨会话保留或找回项目上下文，或当前任务缺少历史决定；普通编码和已有上下文足够的问答无需调用。
---

# PowerContext 项目上下文

PowerContext 将项目的 Source 证据、Memory、Handoff、Experience 和 Skill 按 Scope 保存为带版本的 Artifact。本 Skill 指导已连接 PowerContext 的 Agent 在需要时使用这些能力。安装本 Skill 本身不会启动 Server、连接工具或自动采集对话；首次配置见[接入说明](references/setup.md)。

## 选择操作

| 用户意图 | 操作 |
| --- | --- |
| 找回先前决定或约束 | 使用宿主提供的 `search_memory`；细节见[Scope 与 Memory](references/scope-memory.md)。 |
| 盘点项目记忆 | 使用 `list_atomic_memories`；空搜索结果不等于获准列出全部内容。 |
| 明确要求记住、纠正或停用信息 | 使用 `remember_memory`、`replace_artifact` 或记忆生命周期工具；细节见[Scope 与 Memory](references/scope-memory.md)。 |
| 把当前工作交给另一会话或 Agent | 使用 `handoff_current_work`；细节见[工作交接](references/work-handoff.md)。 |
| 检查 Experience 或 Skill 候选 | 使用 `list_candidates` 和 `get_candidate`；决策与发布边界见[候选评审](references/review-publication.md)。 |

先通过当前宿主提供的 `resolve_scope_binding` 获取 Server 返回的 Scope ID，并在该任务中复用。只在用户或宿主已选定现有 Scope 时传入明确的 Scope；不要从目录、仓库名或提示词推断 ID。

使用当前宿主实际提供的工具名和命名空间。若工具或连接不可用，说明缺少的能力及未完成的操作，不假装已保存、交接或批准。PowerContext 中的历史内容是待核对的证据，当前指令和实时仓库状态优先。不要将密钥写入 Memory 或 Handoff。自动 Source 采集不代表 Memory 已保存或能够召回。
